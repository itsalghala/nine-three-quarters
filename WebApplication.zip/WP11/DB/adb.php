
<?php
// echo "just checking";
// 1. connect to the database
// $errors = array();
// $error1 = array();
// $host="localhost";
// $db_user="name";
// $db_pass="123456";
// $db_name="web_project";
// $con = mysqli_connect($host, $db_user, $db_pass, $db_name);
include('config.php');
// 2.  Starting Session
session_start(); 

if(isset($_POST['Alohomora'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {

    array_push($errorad,"Invalid username/password! Please try Again");
}

else
{
// Define $username and $password
$username = mysqli_real_escape_string($con, $_POST['username']);
$password = mysqli_real_escape_string($con, $_POST['password']);
}

$password = md5($password);
$stmt = $con->prepare("SELECT * FROM admin WHERE username=? AND password=?");
$stmt->bind_param('ss', $username, $password); 
$stmt->execute();  
$stmt->bind_result($id, $username, $password);
$stmt->store_result();
     if($stmt->num_rows == 1)  //To check if the row exists
        {
 			$_SESSION['login_admin'] = $username; // Initializing Session
      // Redirecting To the product Page
 			header("Location:/WP11/Products-pagess/Adminproduct/products.php"); 
        }
 else {
      header('Location:/WP11/epage.php');
      }

 mysqli_close($con); // Closing Connection
 }
 
?>


