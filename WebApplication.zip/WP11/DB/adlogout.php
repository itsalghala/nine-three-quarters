<?php
include('../DB/adsession.php');
session_destroy();
 // Destroying All Sessions
header("Location:../Registerations/admin/login-page.php"); // Redirecting To Home Page
?>