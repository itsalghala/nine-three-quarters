<?php include('../DB/config.php') ?>
<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameters
// Starting Session
session_start();
// Storing Session
$user_check=$_SESSION['login_admin'];
// SQL Query To Fetch Complete Information Of User
$get_all = "SELECT username FROM admin WHERE username='$user_check'";
$ses_sql=mysqli_query($con, $get_all);
$row = mysqli_fetch_assoc($ses_sql);
$admin_session =$row['username'];
if(!isset($admin_session)){
// Closing Connection
mysqli_close($connection); 
// Redirecting to unauthorised Page
header('Location:../epage.php'); 
}
?>

