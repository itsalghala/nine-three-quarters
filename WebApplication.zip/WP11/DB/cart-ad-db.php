
<?php
include('config.php');
//deals with products table in DataBae through assigned CODES
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query($con,"SELECT * FROM `products` WHERE `code`='$code'");
//retutn array with key names
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$code = $row['code'];
$desc = $row['desc'];
$price = $row['price'];
$quantity=$row['quantity'];
$image = $row['image'];

$cartArray = array(
	$code=>array(
	'name'=>$name,
	'code'=>$code,
	'desc'=>$desc,
	'price'=>$price,
    'quantity'=>$quantity,
	'image'=>$image)
);
	}
?>