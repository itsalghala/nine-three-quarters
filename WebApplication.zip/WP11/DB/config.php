<?php
//config file
$host="localhost";
$db_user="name";
$db_pass="123456";
$db_name="web_project";
$con = mysqli_connect($host, $db_user, $db_pass, $db_name);
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: " . mysqli_connect_error();
die();
} 

?>