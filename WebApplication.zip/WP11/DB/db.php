
<?php include('config.php') ?>
<?php
session_start();
// empty errors alert
$errors = array();
$error1 = array();
// input validation error
$nameError ="";
$emailError ="";
$pwdError="";
$verror=0;
// connect to the database
if($con){
    if (isset($_POST['signup'])) {
        // receive all input values from the signup-page.php form
        $username = mysqli_real_escape_string($con, $_POST['username']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password = mysqli_real_escape_string($con, $_POST['password']);
        // by using array_push() corresponding errors in $errors() which is an array of errors.
        if (empty($username)) {
        array_push($errors, "Username is required");
        }
        if (empty($email)) {
        array_push($errors, "Email is required");
        }
        if (empty($password)) {
            array_push($errors, "Password is required");
            }
        //firstly check in database that a user does not already exist with the same username and/or email.
        $get_all = "SELECT * FROM users WHERE username='$username' LIMIT 1";
        $result = mysqli_query($con, $get_all);
        $users = mysqli_fetch_assoc($result);

        // check if the username exists 
        if ($users['username'] === $username) {
            $nameError = "$username is already existed, please choose another";
        }
       
        if ($email) {
        //Validating email
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailError = "$email is a valid email address";   
            } else {
                $verror+=1;
                $emailError = "$email is a not valid email address";  
            }
        } 

        if($password){
            $number = preg_match('@[0-9]@', $password);
            $uppercase = preg_match('@[A-Z]@', $password);
            $lowercase = preg_match('@[a-z]@', $password);
            $specialChars = preg_match('@[^\w]@', $password);
 
            if(strlen($password) < 8 || !$number || !$uppercase || !$lowercase || !$specialChars) {
                $pwdError= "Password must be at least 8 characters in length and must contain at least one number, one upper case letter, one lower case letter and one special character.";
                $verror+=1;
            
            } else {
                $pwdError= "Your password is strong.";
                }
        }

       
        // Finally, register user if no error
        if (($verror == 0) && count($errors) == 0  ){
            $password = md5($password);//encrypt the password before inserting in the database

            $users = "INSERT INTO users(username, email, password)
                    VALUES('$username', '$email', '$password')";
            mysqli_query($con, $users);
        }
    
    }
    if (isset($_POST['signin'])) {
        $username = mysqli_real_escape_string($con, $_POST['username']);
        $password = mysqli_real_escape_string($con, $_POST['password']);

        if (empty($username)) {
            array_push($error1, "Username is required");
        }
        else if (empty($password)) {
            array_push($error1, "Password is required");
        }
        else{
            $password = md5($password);
            $login = "SELECT * FROM users WHERE username='$username' AND password='$password'";
            $results = mysqli_query($con, $login);
            if (mysqli_num_rows($results) == 1) {
               $_SESSION['login_user']=$username;
                header('location:../../Products-pagess/productviewer.php');
            }else {
                array_push($error1,"Invalid username/password! Please try Again");
                
            }
        }
    }
    
}
?>