<?php
// this php code will redirect us to the unauthorised page if there is an error exist.
if (count($errorad) > 0)
{ ?>
    <div class="error">
        <?php foreach ($errorad as $error)
        { ?>
        <?php 
         header('location:../epage.php');
     
    ?>
        <?php }?>
    </div>
<?php
} ?>

