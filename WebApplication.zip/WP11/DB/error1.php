<?php
if (count($error1) > 0)
{ ?>
    <div class="error">
        <?php foreach ($error1 as $error)
        { ?>
        <?php echo '<script type="text/javascript">alert("'.$error.'");</script>'; ?>
        <?php }?>
    </div>
<?php
} ?>