<?php include('../DB/config.php') ?>
<?php
// empty errors alert
$errors = array();
$error1 = array();
// input validation error
$nameError ="";
$emailError ="";
$pwdError="";
$verror=0;

if($con){
    if (isset($_POST['submit'])) {
        // receive all input values from the register.php form
        $username = mysqli_real_escape_string($con, $_POST['username']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $feedback = mysqli_real_escape_string($con, $_POST['feedback']);
        // by using array_push() corresponding errors in $errors() which is an array of errors.
        if (empty($username)) {
        array_push($errors, "Username is required");
        }
        if (empty($email)) {
        array_push($errors, "Email is required");
        }
        if (empty($feedback)) {
            array_push($errors, "feedback is required");
            }
		if ($username) {
					//Sanatizing
					$username = filter_var($username, FILTER_SANITIZE_STRING);	
		} 
        if ($email) {
        //Validating          
            //Validating
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailError = "$email is a valid email address";
                
            } else {
                $verror+=1;
                $emailError = "$email is a not valid email address";
                
            }
	
        } 
		if ($feedback) {
			//Sanatizing
			$feedback =filter_var($feedback, FILTER_SANITIZE_STRING);	
} 

    if (($verror == 0) && count($errors) == 0){
            $sql = "INSERT INTO feedbacks(username, email, feedback)
                    VALUES('$username', '$email', '$feedback')";
            mysqli_query($con, $sql);
   
    
    }
}
}
?>

