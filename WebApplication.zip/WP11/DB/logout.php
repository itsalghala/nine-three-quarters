<?php
include('../DB/session.php');
session_destroy();
 // Destroying All Sessions
header("Location:../WelcomePage/welcomepage.php"); // Redirecting To Home Page
?>