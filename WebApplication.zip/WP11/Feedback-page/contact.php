
<?php
   $file = $_GET['file'];
   if(isset($file))
   {
       include("pages/$file");
   }
   else
   {
       include("index.php");
   }
?>
<br>
<?php echo "Phone number: 5005001"; ?>
<br>
<?php echo "Email: internal@server.com"; ?>
<br>
<?php echo "Thank You."; ?>