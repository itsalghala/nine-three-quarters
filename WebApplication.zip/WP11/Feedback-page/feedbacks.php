<?php
 
   include('../DB/feed-db.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="feedback.css">
    <link rel="stylesheet" href="../nav-css/nav.css">
    <title>Feedback</title>
</head>
<body>
  <!-- logo + navigation bar -->
  <header>
        <div class="container" >
            <div id="branding">
                <div id="logo" >
                  <img src="../logo.png" width="50px" height="auto">
                </div>
                <nav>
                  <ul>
                  <li><a class="active" href="../WelcomePage/welcomepage.php">HOME</a></li>
                  <li><a  href="../slide-page/slideShow.php">ABOUT US</a></li>
                  <li><a  href="../Feedback-page/feedbacks.php" disabled>FEEDBACK</a></li>  
                  <li><a  href="../Products-pagess/Old-product-page/oldcart.php">PRODUCTS</a></li> 
                  <li ><a  class="SIGNIN"  href="../DB/logout.php" disabled> LOGOUT </a></li>
                  </ul>
               </nav>
            </div>
        </div>                 
    </header>
    <br>
<br>
<br>
<br>

    <form action="feedbacks.php" method="POST">
        <?php include("../DB/error.php"); ?>
         <div>
             <label class="label1" for="name">Name</label>
             <input class="box2" type="text" name="username"id="=name" placeholder="User Name" required>
         </div>
         <br>
        <div>
             <label class="label1" for="name">Email</label>
             <input class="box2" type="email" name="email" id="=email" placeholder="Email"required> 
             <p class="errorcolor"><?php echo $emailError;?></p>   

         </div>
         <br>
         <div>
         <label class="label1" for="Feedback">Feedback<br></label>
        <br>
         <textarea  placeholder=" Your Feedback" id="Feedback" name="feedback" rows="3" cols="30" ></textarea>
         </div>
         <br>
          <div class="box1">
             <button class="btn" type="reset">Reset</button>
            </div>
          <div class="box1"> 
             <button name="submit" class="btn" type="submit">Submit</button>
            </div>   
         <br>  
    </form>





<a href=feedbacks.php?page=contact.php class="contact-info">contact information</a>
<?php include('../light-footer.php'); ?>
<?Php

// normal vulnerable code
// $page = $_GET['page']; 
// include($page);

// countermeasures:

// 1. basename()
    // $page = basename(($_GET['page']));
    // include($page);

// 2. change it to post 

// 3. whitelist
$ok = array('contact.php', 'secret.php','../flag5.txt','final.jpeg','php://filter/convert.base64-encode/resource=secret.php','rce.php');
if(isset($_GET['page'])){
 if (!(in_array($_GET['page'],$ok))) {  
   header("location:../epage.php");  }
 else {
    include($_GET['page']);
  }
 }
?>



 </body>

 

</html>

