<?php 

echo "This is a secret file.";

// if you're looking for Nagini.. go to rce.php
// and remember Never trust anything that can think for itself if you can’t see where it keeps its brain ..

?>