<?php 
include('../../DB/config.php');
include('../../DB/adsession.php');

?>
<?php
    if(!isset($_GET['id'])){
        // if no id found dont accept
        die('id not provided');
    }
    include('../../DB/cart-ad-db.php');
    $id =  $_GET['id'];
    $sql = "SELECT * FROM `products` where id = $id";
    $result = $con->query($sql);
    $data = $result->fetch_assoc();
   

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="EditProduct.css">
    <link rel="stylesheet" href="../../nav-css/nav.css">
    <title>Edit Product</title>
    <header>
    <div class="container1" >
     
            <div class="container" >
                <div id="branding">
                    <div id="logo" >
                        <!-- image -->
                        <img src="../../logo.png" width="50px" height="auto">
            
                    </div>
                    <nav>
                    <ul>
                    <li><b id="welcome">Welcome : <i><?php echo $admin_session; ?></i></b></li>
                    <li><a  href="../../Products-pagess/Adminproduct/products.php">PRODUCTS</a></li>
                        <li><a  class="LOGOUT-D"  href="../../DB/adlogout.php"> LOGOUT </a></li>
                      
                    </ul>
                </nav>
                </div>
            </div>                 
    </div>
</header>
</head>
<body>
 
<div class="page">
<!--starting of the form-->
<form action="./edit.php?id=<?= $id ?>" method="POST">
  <br><br>
  <h1> Product</h1>
  <br><hr>
  <fieldset>
          <label for="price">Product Name<br><br></label>
          <input class="floatlabel" type="text" class="form-control" name="name" id="name" value="<?= $data['name']?>" disabled>
  </fieldset>

  <fieldset>
          <label for="price">Price<br><br></label>
          <input class="floatlabel" type="number" name="price" id="price" value="<?= $data['price']?>">
          
  </fieldset>
  <fieldset>
            <label for="price">Quantity<br><br></label>
            <input class="floatlabel"  type="number" name="quantity" id="quantity" value="<?= $data['quantity']?>">
  </fieldset>
  <fieldset>
            <br><br><input type="submit" name="editForm" value="submit">
  	</fieldset>
    <!--end of the form-->
</form>
</body>

    <?php include('../../light-footer.php'); ?>
    
</div>
</html>