
<?php
    include('../../DB/cart-ad-db.php');
    if(isset($_GET['id']) && isset($_POST['editForm'])){
        $id = $_GET['id'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $quantity=$_POST['quantity'];

        $sql = "UPDATE `products` SET 
                `price`= '$price',
                `quantity`= '$quantity' 
                 WHERE id = $id";
          
        if($con->query($sql) === TRUE){
            //if update done successfully return to products page
            header('Location:../../Products-pagess/Adminproduct/products.php');
        }else{
            echo "something went wrong";
        }
    }else{
        echo "invalid";
    }
?>

