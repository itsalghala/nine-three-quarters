<?php 

/*
code source:
Author: Javed Ur Rehman
Website: https://www.allphptricks.com
*/

include('../../DB/config.php');
include('../../DB/adsession.php');
?>

<?php
 include('../../DB/cart-ad-db.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="product.css">
    <link rel="stylesheet" href="nav.css">
    <title>Admin Product Page</title>
</head>
<body>
<!-- navigation bar -->
<div class="container1" >
<header>
        <div class="container" >
            <div id="branding">
                <div id="logo" >
                    <!-- image -->
                    <img src="../../logo.png" width="50px" height="auto">
                </div>
                <nav>
                  <ul>
                  <li><b id="welcome" class="welcome">Welcome : <i><?php echo $admin_session; ?></i></b></li>   
                    <li ><a  class="LOGOUT-L"  href="../../DB/adlogout.php"> LOGOUT </a></li>
                    </ul>
                  </ul>
               </nav>
            </div>
        </div>                 
    </header> 
</div>
        <!--end of navigation bar-->

    <!-- wrapper -->
    <div class="wrapper">
    
        <!-- items container -->
            <div class="items">
                        
                        <?php
                        $result = mysqli_query($con,"SELECT * FROM `products`");
                        while($row = mysqli_fetch_assoc($result)){
                        echo "<div class='product_wrapper'>
                    <!-- item -->
                        <div class='item'>
                        <form method='post' action='EditProduct.php'>
                        <input type='hidden' name='code' value=".$row['code']." />
                        <img src='".$row['image']."' />
                        <h2>".$row['name']."</h2>
                        <p>Price:<em>".$row['price']."</em>$</p>
                        <p>Description: <em>".$row['description']."</em></p>
                        <p>Item Quantity: <em>".$row['quantity']."</em></p>
                        <a class='add' href='./EditProduct.php?id=" .$row['id'] ."'> Edit </a>
                        </form>
                    <!-- end of item -->
                        </div>";
                                }
                        mysqli_close($con);
                            ?>
                <!-- end product wrapper -->                  
                </div>
        <!--end of items -->                    
        </div>
    <!-- end of wrapper -->
    </div>
    
    <script src="product.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</body>
</br> </br>
<?php
//  include("../../dark-footer.php");
 ?>
<!-- Yes! you did bypass the admin page but the flag is in the final.jpeg -->
</html>
