<?php 

/* 
source: (1) codepen, and (2) uxplanet
url: 
(1) https://codepen.io/
(2) https://uxplanet.org/how-to-create-a-shopping-cart-ui-using-html-css-e5db3cd55aa0
*/

include('../../DB/config.php');
include('../../DB/session.php');
?>
<?php




$status="";
//code to remove a single item
if (isset($_POST['action']) && $_POST['action']=="remove"){

	foreach($_SESSION["shopping_cart"] as $key => $value) {
		if($_POST["code"] == $key){ //remove the product from cart by using product code
		unset($_SESSION["shopping_cart"][$key]);
		$status = "<div class='box' style='color:white;'>
		Product is removed from your cart!</div>";
		}
		if(empty($_SESSION["shopping_cart"]))
		unset($_SESSION["shopping_cart"]); //resets the shopping cart
			}		
		
}
//code to clear the whole cart
if (isset($_POST['action']) && $_POST['action']=="clear"){
  foreach($_SESSION["shopping_cart"] as $key) {
		unset($_SESSION["shopping_cart"][$key]);
		$status = "<div class='box' style='color:white;'>
		Cart is cleared!</div>";
  }
  unset($_SESSION["shopping_cart"]); //resets the shopping cart
		
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Shopping Cart</title>
	<link rel="stylesheet" type="text/css" href="Cart.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,900" rel="stylesheet">
  <link rel="stylesheet" href="../../nav-css/nav.css">
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <div id='stars'></div>
    <div id='stars2'></div>
    <div id='stars3'></div>
    <header>
        <div class="container" >
            <div id="branding">
                <div id="logo" >
                  <img src="../../logo.png" width="50px" height="auto">
                </div>
                <nav>
                  <ul>
                  <li><li><form action="oldcart.php" method="GET"> <input class="example" type="text" placeholder="Search.." name="search" ></li> </form></li>
                  <li><b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b></li>
                  <li><a class="active" href="../../WelcomePage/welcomepage.php">HOME</a></li>
                  <li><a  href="../../slide-page/slideShow.php">ABOUT US</a></li>
                  <li><a  href="../../Feedback-page/feedbacks.php">FEEDBACK</a></li>  
                  <li><a  href="../../Products-pagess/Old-product-page/oldcart.php">PRODUCTS</a></li> 
                  <li ><a  class="SIGNIN"  href="../../DB/logout.php"> LOGOUT </a></li>
                  </ul>
               </nav>
            </div>
        </div>                 
    </header>
</head>

<body>  
  <div class="page">
   <div class="CartContainer">
   	   <div class="Header1">
   	   	<h3 class="Heading">Shopping Cart </h3>
   	   </div>
    
                        <!-- code here is done to be a fix for the first button not functioning in the container -->
                        <form method='post' action=''>
                        <input type='hidden' name='code' value="<?php echo $product["code"]; ?>" />
                        <input type='hidden' name='action' value="fix"/>
                        </form>
                        <!-- end of fix -->
<div class="cart">
  <div class="Cart-Items">

    <?php
    if(isset($_SESSION["shopping_cart"])){
        $total_price = 0;
    ?>	
          <!-- div to display checkout and clear buttons -->
          <div class="checkout_clear">
          <form method='POST' action=''>
                        <input type='hidden' name='code' value="<?php echo $product["code"]; ?>" />
                        <input type='hidden' name='action' value="clear"/>
                        <button type='submit' class='clear'>Clear Items</button>
          </form>
          <a  class="checkout" href="../../payment-page/payment.php"> Checkout </a>
          </div>

          <!-- table to display the cart content -->
          <div class="tablediv"> 
          <table class="table" width=95%>
          <tbody>
          <tr>
          <td></td>
          <td>ITEM NAME</td>
          <td></td>
          <td> PRICE</td>
          </tr>	
          <?php		
          foreach ($_SESSION["shopping_cart"] as $product){ //to display each product in the table
          ?>
          <tr>
          <td><img src='<?php echo $product["image"]; ?>' width="50" height="40" /></td>
          <td><?php echo $product["name"]; ?><br/>
          <form method='post' action=''>
          <input type='hidden' name='code' value="<?php echo $product["code"]; ?>" />
          <input type='hidden' name='action' value="remove" />
          <button type='submit' class='remove'>Remove Item</button>
          </form>
          
          </td>
          <td>
        
          </td>
          <td><?php echo "$".$product["price"]; ?></td>
          </tr>
          <?php
          $total_price += ($product["price"]*1); //calculates the total price of the cart
          
          }
          ?>

        <tr>
        <td colspan="5" align="right">
        <strong>TOTAL: <?php echo "$".$total_price; ?></strong> <!-- displays the total of the price in the table -->
        <br>
        </td>
          
        </tr>
        </tbody>

        </table>

        </div>

  </div>
</div>

    <?php
    //the 'else' of the if condition here means shopping cart is empty (doesn't exist/not set) 
  }else{ 
    echo "<h3 style='margin-left:20px;'>  Your cart is empty!</h3>";
    }
    ?>
</div>

<div style="clear:both;"></div>

  <div class="message_box" style="margin:10px 0px;">
  <?php echo $status; ?>

  </div>
</div>
   	</div>

     <?php include('../../light-footer.php'); ?>

  </div>
</body>
</html>
