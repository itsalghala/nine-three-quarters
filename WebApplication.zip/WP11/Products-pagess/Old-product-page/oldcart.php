<?php 



include('../../DB/config.php');
include('../../DB/session.php');

?>
<?php



// begining of php code
// session starts here
session_start();

// get data from database and save in variables 
$status="";
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query($con,"SELECT * FROM `products` WHERE `code`='$code'");
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$code = $row['code'];
$desc = $row['desc'];
$price = $row['price'];
$image = $row['image'];

// create an array
$cartArray = array(
	$code=>array(
	'name'=>$name,
	'code'=>$code,
	'desc'=>$desc,
	'price'=>$price,
	'image'=>$image)
);

// check if product is already in the cart
if(empty($_SESSION["shopping_cart"])) {
	$_SESSION["shopping_cart"] = $cartArray;
	$status = "<div class='box'>Product is added to your cart!</div>";
}else{
	$array_keys = array_keys($_SESSION["shopping_cart"]);
	if(in_array($code,$array_keys)) {
		$status = "<div class='box' style='color:red;'>
		Product is already added to your cart!</div>";	
	} else {
	$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"], $cartArray);
	$status = "<div class='box'>Product is added to your cart!</div>";
	}

	}
}
// end of php code
?>

<!-- begining of html code -->
<!DOCTYPE html>
<html lang="en">

<!-- head -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="product.css">
    <link rel="stylesheet" href="nav.css">
    <title>Product Page</title>
</head>

<!-- body -->

<body>
<header>
        <div class="container" >
            <div id="branding">
                <div id="logo" >
                  <img src="../../logo.png" width="50px" height="auto">
                </div>
                <nav>
                  <ul>
                  <li><li><form action="oldcart.php" method="GET"> <input class="example" type="text" placeholder="Search.." name="search" ></li> </form></li>
                  <li><b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b></li>
                  <li><a class="active" href="../../WelcomePage/welcomepage.php">HOME</a></li>
                  <li><a  href="../../slide-page/slideShow.php">ABOUT US</a></li>
                  <li><a  href="../../Feedback-page/feedbacks.php">FEED BACK</a></li>  
                  <li><a  href="../../Products-pagess/Old-product-page/oldcart.php">PRODUCTS</a></li> 
                  <li ><a  class="LOGOUT-D"  href="../../DB/logout.php"> LOGOUT </a></li>
                  </ul>
               </nav>
            </div>
        </div>                 
    </header>
<!-- wrapper -->
<div class="wrapper">

        <!-- items -->
        <div class="items">

        <?php


if (isset($_GET['search']))
{
    if (!empty($_GET['search']))
{
    $search=mysqli_real_escape_string($con, $_GET['search']); 
    $search=strtoupper($search);
    if ($search) {
        $search = filter_var($search, FILTER_SANITIZE_STRING);	
        }

    $query_search ="SELECT * FROM products WHERE name LIKE '%{$search}%'";
    $result = mysqli_query($con, $query_search);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0){
        echo "
                <div class='product_wrapper'>
                <div class='item_search'>
                <!-- single item -->
                <form method='post' action=''>
				<input type='hidden' name='code' value=".$row['code']." />
                <em><h3>Search Result: </h3></em>
                </br>
                <img src='".$row['image']."' />
                <h3>".$row['name']."</h3>
                <p>Price:<em>".$row['price']."</em>$</p>
                <p>Description: <em>".$row['description']."</em></p>
				</form>
                </div>
                <!--/ single item ends -->";
    }
    else 
    if ($row['name']!== $search){
            echo "
            <div class='product_wrapper'>
            <div class='item_search'>
            <!-- single item -->
            <em><h3>Search Result: </h3></em>
            </br>
            <img src='product-images/not-exist.png' alt='product is not available' style='height: 65px width: auto'/>
            <h3>Sorry to tell you that the product is not available... try again later.</h3>
            </div>
            <!--/ single item ends -->";
        }

}

}

?>


            <!-- single item -->
            <?php
                if(!empty($_SESSION["shopping_cart"])) 
                {
                $cart_count = count(array_keys($_SESSION["shopping_cart"]));
            ?>
            <div class="cart_div">
                <a href="../Old-product-page/cart.php"><img src="cart-icon.png" /> Cart<span><?php echo $cart_count; ?></span></a>
            </div>
            <?php 
            }
            $result = mysqli_query($con,"SELECT * FROM `products`");
            while($row = mysqli_fetch_assoc($result))
            {
                echo "
                <div class='product_wrapper'>
                <div class='item'>
                <!-- single item -->
                <form method='post' action=''>
				<input type='hidden' name='code' value=".$row['code']." />
                <img src='".$row['image']."' />
                <h2>".$row['name']."</h2>
                <p>Price:<em>".$row['price']."</em>$</p>
                <p>Description: <em>".$row['description']."</em></p>
                <div><button class='add' type='submit'>Add to cart</button></div>
				</form>
                </div>";
            }
            
            mysqli_close($con);

            ?>                    
        </div>
        <!--/ single item ends -->
    </div>
    <!--/ items ends -->

</div>
<!--/ wrapper ends -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</body>
        </br> </br>
        <?php include('../../light-footer.php'); ?>

</html>
