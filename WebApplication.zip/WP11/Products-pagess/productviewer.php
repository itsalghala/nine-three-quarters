<!DOCTYPE html>
<?php 
include('../DB/session.php');
?>
<html lang="en">

<!-- head -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css">
    <link rel="stylesheet" href="productviewer.css">
  <link rel="stylesheet" href="../nav-css/nav.css">
</head>

<!-- body -->
<body>
  <!-- logo + navigation bar -->
  <header>
        <div class="container" >
            <div id="branding">
                <div id="logo" >
                  <img src="../logo.png" width="50px" height="auto">
                </div>
                <nav>
                  <ul>
                  <li><b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b></li>
                  <li><a class="active" href="../WelcomePage/welcomepage.php">HOME</a></li>
                  <li><a  href="../slide-page/slideShow.php">ABOUT US</a></li>
                  <li><a  href="../Feedback-page/feedbacks.php">FEEDBACK</a></li>  
                  <li><a  href="../Products-pagess/Old-product-page/oldcart.php">PRODUCTS</a></li> 
                  <li ><a  class="SIGNIN"  href="../DB/logout.php"> LOGOUT </a></li>
                  </ul>
               </nav>
            </div>
        </div>                 
    </header>

    
    <!-- wrapper -->
    <div class="wrapper">

        <div class="content">
          <div class="bg-shape">
            <img src="Images/logo-to-use-for-bg-sized.png" alt="LOGO">
          </div>
          
          <!-- products images  -->
           <div class="product-img">

            <div class="product-img__item" id="img1">
              <img src="Images/time.jpg" alt="time" class="product-img__img">
            </div>
      
            <div class="product-img__item" id="img2">
              <img src="Images/cup.jpg" alt="cup" class="product-img__img">
            </div>
      
            <div class="product-img__item" id="img3">
              <img src="Images/snitch.jpg" alt="snitch" class="product-img__img" width="97%">
            </div>
      
            <div class="product-img__item" id="img4">
              <img src="Images/ring.jpg" alt="ring" class="product-img__img">
            </div>
      
            <div class="product-img__item" id="img5">
             
              <img src="Images/coin.jpg" alt="coin" class="product-img__img" width="92%">
            </div>

            <div class="product-img__item" id="img6">
              <img src="Images/luna.jpg" alt="luna" class="product-img__img" width="97%" >
            </div>

            <div class="product-img__item" id="img7">
              <img src="Images/tom.jpg" alt="tom" class="product-img__img">
            </div>

            <div class="product-img__item" id="img8">
              <img src="Images/ticket.jpg" alt="ticket" class="product-img__img" width="90%">
            </div>

            <div class="product-img__item" id="img9">
              <img src="Images/map.jpg" alt="map" class="product-img__img" width="75%">
            </div>

            <div class="product-img__item" id="img9">
              <img src="Images/locket.png" alt="locket" class="product-img__img" width="75%">
            </div>

          </div>
          <!-- /product images -->
        
      
          
          <div class="product-slider">
            <!-- back arrow -->
            <button class="prev disabled">
              <span class="icon">
                <svg class="icon icon-arrow-right"><use xlink:href="#icon-arrow-left"></use></svg>
              </span>
            </button>
            <!-- /back arrow -->
            
            <!-- next arrow -->
            <button class="next">
              <span class="icon">
                <svg class="icon icon-arrow-right"><use xlink:href="#icon-arrow-right"></use></svg>
              </span>
            </button>
            <!-- /next arrow -->
            
            <!-- product 1 -->
            <div class="product-slider__wrp swiper-wrapper">
              <div class="product-slider__item swiper-slide" data-target="img1">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">HERMIONE'S TIME TURNER PIN</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">A replica of Hermione's Time-Turner, on a pin badge. It has glittering rhinestones to represent an hourglass.</div>
                      </div>
                    </div>
              
                    <div class="product-slider__bottom">
                      <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                  </div>
                  </div>
                </div>
              </div>
              <!-- /product 1 -->
              
              <!-- product 2 -->
              <div class="product-slider__item swiper-slide" data-target="img2">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">THE TRIWIZARD LIGHT CUP</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">Inspired by the golden cup, When switched on stem lights up bright blue to emulate the way the cup glows as seen.</div>
                      </div>
                    </div>
                
                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 2 -->

              <!-- product 3 -->
              <div class="product-slider__item swiper-slide" data-target="img3">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">GOLDEN SNITCH KEYRING </h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">This keyring features a 3D replica of the iconic Golden Snitch, its a metallic gold color with silver wing detailing.</div>
                      </div>
                    </div>

                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 3 -->

              <!-- product 4 -->
              <div class="product-slider__item swiper-slide" data-target="img4">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">THE HORCRUX RING SOUVENIR </h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <p class="product-labels__desc">This Ring is plated in 24 gold and comes in a customized collector's display box. It is available in size 10 only.
                      </div>
                    </div>
                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 4 -->
              
              <!-- product 5 -->
              <div class="product-slider__item swiper-slide" data-target="img5">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">SET OF GRINGOTTS BANK COINS</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">This is a replicate of the money used in the Harry Potter film series. Each double-sided coin is hand struck in 24k gold, silver or bronze.</div>
                      </div>
                    </div>

                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                      
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 5 -->

              <!-- product 6 -->
              <div class="product-slider__item swiper-slide" data-target="img6">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">LUNA'S SPECTRESPECS PIN BADGE</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">Luna Lovegood was first seen wearing a pair of Spectrespecs Luna Lovegood on the train ride to Hogwarts in 1996.</div>
                      </div>
                    </div>
            
                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 6 -->

              <!-- product 7 -->
              <div class="product-slider__item swiper-slide" data-target="img7">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">TOM RIDDLE REPLICA DIARY</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">This is a replica of Riddle's Diary but be careful that he doesn't write back! its leather journal measures 20cm x 13cm with 142 blank pages. </div>
                      </div>
                    </div>
                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 7 -->

              <!-- product 8 -->
              <div class="product-slider__item swiper-slide" data-target="img8">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">HOGWARTS EXPRESS SOUVENIR TICKET</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">This ticket is embellished with gold foil, and is based on the original artwork by MinaLima, the graphic duo.</div>
                      </div>
                    </div>
              
                    <div class="product-slider__bottom">
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 8 -->

              <!-- product 9 -->
              <div class="product-slider__item swiper-slide" data-target="img9">
                <div class="product-slider__card">
                  <img src="Images/hogwatrs-bg-products-sized.png" alt="HOGWARTS" class="product-slider__cover">
                  <div class="product-slider__content">
                    <h1 class="product-slider__title">THE MARAUDER'S MAP</h1>
                    <div class="product-ctr">
                      <div class="product-labels">
                        <div class="product-labels__title">PRODUCT DESCRIPTION</div>
                        <div class="product-labels__desc">This Map replica. It shows every classroom and hallway, including all the hidden secret passages and the location of every person in the Hogwarts grounds.</div>
                      </div>
                    </div>
            
                    <div class="product-slider__bottom">
                    
                    <!-- <form action="\WP9\Products-pagess\Old-product-page\oldcart.php" method="">
                        <button class="product-slider__cart">ADD TO CART</button>
                      </form> -->
                  
                    </div>
                  </div>
                </div>
              </div>
              <!-- /product 9 -->
      
            </div>
          </div>
      
        </div>
      
       
    </div>
    <!-- /wrapper -->

      <svg class="hidden" hidden>
        <symbol id="icon-arrow-left" viewBox="0 0 32 32">
          <path d="M0.704 17.696l9.856 9.856c0.896 0.896 2.432 0.896 3.328 0s0.896-2.432 0-3.328l-5.792-5.856h21.568c1.312 0 2.368-1.056 2.368-2.368s-1.056-2.368-2.368-2.368h-21.568l5.824-5.824c0.896-0.896 0.896-2.432 0-3.328-0.48-0.48-1.088-0.704-1.696-0.704s-1.216 0.224-1.696 0.704l-9.824 9.824c-0.448 0.448-0.704 1.056-0.704 1.696s0.224 1.248 0.704 1.696z"></path>
        </symbol>
        <symbol id="icon-arrow-right" viewBox="0 0 32 32">
          <path d="M31.296 14.336l-9.888-9.888c-0.896-0.896-2.432-0.896-3.328 0s-0.896 2.432 0 3.328l5.824 5.856h-21.536c-1.312 0-2.368 1.056-2.368 2.368s1.056 2.368 2.368 2.368h21.568l-5.856 5.824c-0.896 0.896-0.896 2.432 0 3.328 0.48 0.48 1.088 0.704 1.696 0.704s1.216-0.224 1.696-0.704l9.824-9.824c0.448-0.448 0.704-1.056 0.704-1.696s-0.224-1.248-0.704-1.664z"></path>
        </symbol>
      </svg>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
      <script src="productviewer.js"></script>
      
</body>
</html>