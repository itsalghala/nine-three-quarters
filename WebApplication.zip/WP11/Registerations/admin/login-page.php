<?php /* source code: https://codepen.io/ainalem/pen/EQXjOR */ ?>
<?php include('../../DB/config.php'); ?>
<?php include('../../DB/adb.php'); ?>
<?php include('../../DB/error-ad.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adminstrator page</title>
    <link rel="stylesheet" href="login-page-css.css">
   
</head>
<body>
 
  <div id='stars'></div>
  <div id='stars2'></div>
  <div id='stars3'></div>
    <div class="page">
        <div class="container">
          <div class="left">
          
         
         
              <h1 class="login" style=" color: #314d5e; font-family: 'Playfair Display', 'serif';">
              Admin
              </h1>
              
             <p class="eula" style=" color: #314d5e; font-family: 'bluu_nextbold', 'Crimson Text', serif;"> Be Aware That There is No Muggle Prime Minister has ever set foot in the Ministry of Magic. </p>
              <div class="logoheading">
              <img class="imghead" src="adminlogo.png" width="80px" height="auto" style="margin-left: 130px;"  >
              </div>
              <br>
            <br>
          </div>
          <div class="right">
            
            <svg viewBox="0 0 320 300">
              <defs>
                <linearGradient
                                inkscape:collect="always"
                                id="linearGradient"
                                x1="13"
                                y1="193.49992"
                                x2="307"
                                y2="193.49992"
                                gradientUnits="userSpaceOnUse">
                  <stop
                        style="stop-color:#3a5370;"
                        offset="0"
                        id="stop876" />
                  <stop  
                        style="stop-color:#5a9cd1;"
                        offset="1"
                        id="stop878" />
                </linearGradient>
              </defs>
              <path d="m 40,120.00016 239.99984,-3.2e-4 c 0,0 24.99263,0.79932 25.00016,35.00016 0.008,34.20084 -25.00016,35 -25.00016,35 h -239.99984 c 0,-0.0205 -25,4.01348 -25,38.5 0,34.48652 25,38.5 25,38.5 h 215 c 0,0 20,-0.99604 20,-25 0,-24.00396 -20,-25 -20,-25 h -190 c 0,0 -20,1.71033 -20,25 0,24.00396 20,25 20,25 h 168.57143" />
            </svg>
            <div class="form" >
              <form method="post">
              <label for="uname" style="color: #dce6ec; font-family: 'bluu_nextbold', 'Crimson Text', serif; font-size: 19px;">Name </label>
              <input type="uname" name="username" id="uname" style="font-family: 'bluu_nextbold', 'Crimson Text', serif;" required>
              <label for="password" style="color: #dce6ec; font-family: 'bluu_nextbold', 'Crimson Text', serif; font-size: 19px;">Password </label>
              <input type="password" name="password" id="password" style="font-family: 'bluu_nextbold', 'Crimson Text', serif;">
              <input type="submit" id="submit" name="Alohomora" value="Alohomora" style="font-family: 'bluu_nextbold', 'Crimson Text', serif;" required>
              </form>
            </div>
          </div>
        </div>
      </div>
      <script src='https://cdnjs.cloudflare.com/ajax/libs/animejs/2.2.0/anime.min.js'></script> 
    <script src="login-page-js.js"></script>
</body>
<?php include('../../light-footer.php');?> 

</html>
