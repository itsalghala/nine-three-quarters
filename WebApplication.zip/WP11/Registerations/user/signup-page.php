<?php 
 /* source code: https://codepen.io/kvaibhav01/pen/PgRgzv */

include('../../DB/db.php') ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Page</title>
  <link rel="stylesheet" href="signup-css.css">  
  <link rel="stylesheet" href="../../nav-css/nav.css">
</head>
<body>
<div class="container1" >
<header>
        <div class="container" >
            <div id="branding">
                <div id="logo" >
                    <!-- image -->
                    <img src="../../logo.png" width="50px" height="auto">
                </div>
                <nav>
                  <ul>
                  <!-- <li><a class="active" href="../../WelcomePage/welcomepage.php">HOME</a></li>
                  <li><a  href="../../slide-page/slideShow.php">ABOUT US</a></li>
                  <li><a  href="../../Feedback-page/feedbacks.php">FEEDBACK</a></li>  
                  <li ><a  class="SIGNIN"  href="signup-page.php">SIGN UP</a></li> -->
                  </ul>
               </nav>
            </div>
        </div>                 
    </header> 
</div>

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
  integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
  crossorigin="anonymous">
  <div id='stars'></div>
  <div id='stars2'></div>
  <div id='stars3'></div>
  <!-- Registeration Div -->
<div class="container" id="container">
      <div class="form-container sign-up-container">
            <!-- Create account Form -->
          <form action="signup-page.php" method="post" >
              <?php include('../../DB/error.php'); ?>
              <h1>Create Account</h1>
              <input type="text" name="username" placeholder="Username" />
              <p class="errorcolor"><?php echo $nameError;?></p>
              <input type="text" name="email"  placeholder="Email" />
              <p class="errorcolor"><?php echo $emailError;?></p>
              <input type="password" name="password"   placeholder="Password" />
              <p class="errorcolor"><?php echo $pwdError;?></p>
              <button type="submit" name="signup">Sign Up</button>
          </form>
      </div>
      <div class="form-container sign-in-container">
          <!-- User log in Form -->
          <form action="signup-page.php" method="post">
              <?php include('../../DB/error1.php'); ?>
              <h1>Sign in</h1>
              <input type="text" name="username" placeholder="Username" required="required" /> 
              <input type="password" name="password" placeholder="Password" required="required" /> 
              <button type="submit" name="signin">Sign In</button>
          </form> 
      </div>
       <!-- Overlay contianer -->
      <div class="overlay-container">
          <div class="overlay">
              <div class="overlay-panel overlay-left">
                  <h1 style="color: #dce6ec; font-family: 'Playfair Display', 'serif';">Welcome Back!</h1>
                  <p style="color: #dce6ec; font-family: 'bluu_nextbold', 'Crimson Text', serif;">Wizards welcome Muggles tolerated</p>
                  <button class="ghost" id="signIn">Sign In</button>
              </div>
              <div class="overlay-panel overlay-right">
                  <h1 style="color: #dce6ec; font-family: 'Playfair Display', 'serif';">Hello, Muggles!</h1>
                  <p style="color: #dce6ec; font-family: 'bluu_nextbold', 'Crimson Text', serif;">Enter your personal details and start <br><br> your journey with us<br></p>
                  <button class="ghost" id="signUp">Sign Up</button>
              </div>
          </div>
      </div>
  </div>
  <script src="signup-js.js"></script>
</body>
<?php include('../../light-footer.php');?> 

</html>
