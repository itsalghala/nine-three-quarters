<?php /* source code: https://codepen.io/creativeocean/pen/qBbBLyB */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=100%, initial-scale=1.0">
    <title>Welcome Page</title>
    <link rel="stylesheet" href="welcomepage.css">

</head>
<body>

    <div class="background-container">
        <div class="stars"></div>
    <div class="scrollDist"></div>
    <div class="main">
      <svg viewBox="0 0 1200 800" xmlns="http://www.w3.org/2000/svg">
        <mask id="m">
          <g class="cloud1">
            <rect fill="#fff" width="100%" height="801" y="799" />
            <image xlink:href="https://assets.codepen.io/721952/cloud1Mask.jpg" width="1200" height="800"/>
          </g>
        </mask>
        
        <image class="sky" href="skyblack.jpg"/>
        <image class="mountBg" href="hogwarts.png" width="100%" height="100%" x=-2 y=-10 />    
        <image class="cloud2" xlink:href="https://assets.codepen.io/721952/cloud2.png" width="1200" height="800"/>    
        <image class="cloud1" xlink:href="https://assets.codepen.io/721952/cloud1.png" width="1200" height="800"/>
        <image class="cloud3" xlink:href="https://assets.codepen.io/721952/cloud3.png" width="1200" height="800"/>
        

        <text fill="#fff" x="350" y="200">EXPLORE</text>

        
        <g mask="url(#m)">
         <rect fill="#fff" width="100%" height="100%" />      
         <text x="280" y="200" fill="#414c50">HOGWARTS</text>
        </g>
      
      </svg>
      
    </div>
    <div>
      <a href="../slide-page/slideShow.php" class="button"></a>
    </div>


<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/gsap-latest-beta.min.js"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/ScrollTrigger.min.js"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/ScrollToPlugin3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/zepto/1.2.0/zepto.min.js"></script>
<script src="welcomepage.js"></script>
</body>

<?php include("dark-footer.php");?>


</html>
