<div id="footer">

<p style="color:#1B232F">Platform 9¾ &copy; Internal Server Error </p>

</div>

