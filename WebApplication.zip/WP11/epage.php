<?php /* source code: https://codepen.io/OscarTBeamish/pen/wqMwXy */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=100%, initial-scale=1.0">
    <link rel="stylesheet" href="epage.css">
    <link href="https://fonts.googleapis.com/css?family=IM+Fell+English" rel="stylesheet">
   
    <title>Document</title>
</head>
<body>
    <!-- text -->
<div id="ui">
    <h1 class="pp">401 unauthorised!</h1>
  <p>I solemnly swear that I am up to no good...be aware</p>
  <!-- feet & track -->
  <div class="track track_1">
    <div class="foot left">
      <div class="foot_claw"></div>
      <div class="foot_claw"></div>
      <div class="foot_claw"></div>
    </div>
    <div class="foot right">
      <div class="foot_claw"></div>
      <div class="foot_claw"></div>
      <div class="foot_claw"></div>
    </div>
    <div class="track track_2">
      <div class="foot left">
        <div class="foot_claw"></div>
        <div class="foot_claw"></div>
        <div class="foot_claw"></div>
      </div>
      <div class="foot right">
        <div class="foot_claw"></div>
        <div class="foot_claw"></div>
        <div class="foot_claw"></div>
      </div>
      <div class="track track_3">
        <div class="foot left">
          <div class="foot_claw"></div>
          <div class="foot_claw"></div>
          <div class="foot_claw"></div>
        </div>
        <div class="foot right">
          <div class="foot_claw"></div>
          <div class="foot_claw"></div>
          <div class="foot_claw"></div>
        </div>
        <div class="track track_4">
          <div class="foot left">
            <div class="foot_claw"></div>
            <div class="foot_claw"></div>
            <div class="foot_claw"></div>
          </div>
          <div class="foot right">
            <div class="foot_claw"></div>
            <div class="foot_claw"></div>
            <div class="foot_claw"></div>
          </div>
          <div class="track track_5">
            <div class="foot left">
              <div class="foot_claw"></div>
              <div class="foot_claw"></div>
              <div class="foot_claw"></div>
            </div>
            <div class="foot right">
              <div class="foot_claw"></div>
              <div class="foot_claw"></div>
              <div class="foot_claw"></div>
            </div>
            <div class="track track_6">
              <div class="foot left">
                <div class="foot_claw"></div>
                <div class="foot_claw"></div>
                <div class="foot_claw"></div>
              </div>
              <div class="foot right">
                <div class="foot_claw"></div>
                <div class="foot_claw"></div>
                <div class="foot_claw"></div>
              </div>
              <div class="track track_7">
                <div class="foot left">
                  <div class="foot_claw"></div>
                  <div class="foot_claw"></div>
                  <div class="foot_claw"></div>
                </div>
                <div class="foot right">
                  <div class="foot_claw"></div>
                  <div class="foot_claw"></div>
                  <div class="foot_claw"></div>
                </div>
                <div class="track track_8">
                  <div class="foot left">
                    <div class="foot_claw"></div>
                    <div class="foot_claw"></div>
                    <div class="foot_claw"></div>
                  </div>
                  <div class="foot right">
                    <div class="foot_claw"></div>
                    <div class="foot_claw"></div>
                    <div class="foot_claw"></div>
                  </div>
                  <div class="track track_9">
                    <div class="foot left">
                      <div class="foot_claw"></div>
                      <div class="foot_claw"></div>
                      <div class="foot_claw"></div>
                    </div>
                    <div class="foot right">
                      <div class="foot_claw"></div>
                      <div class="foot_claw"></div>
                      <div class="foot_claw"></div>
                    </div>
                    <div class="track track_10">
                      <div class="foot left">
                        <div class="foot_claw"></div>
                        <div class="foot_claw"></div>
                        <div class="foot_claw"></div>
                      </div>
                      <div class="foot right">
                        <div class="foot_claw"></div>
                        <div class="foot_claw"></div>
                        <div class="foot_claw"></div>
                      </div>
                      <div class="track track_11">
                        <div class="foot left">
                          <div class="foot_claw"></div>
                          <div class="foot_claw"></div>
                          <div class="foot_claw"></div>
                        </div>
                        <div class="foot right">
                          <div class="foot_claw"></div>
                          <div class="foot_claw"></div>
                          <div class="foot_claw"></div>
                        </div>
                        <div class="track track_12">
                          <div class="foot left">
                            <div class="foot_claw"></div>
                            <div class="foot_claw"></div>
                            <div class="foot_claw"></div>
                          </div>
                          <div class="foot right">
                            <div class="foot_claw"></div>
                            <div class="foot_claw"></div>
                            <div class="foot_claw"></div>
                          </div>
                          <div class="track track_13">
                            <div class="foot left">
                              <div class="foot_claw"></div>
                              <div class="foot_claw"></div>
                              <div class="foot_claw"></div>
                            </div>
                            <div class="foot right">
                              <div class="foot_claw"></div>
                              <div class="foot_claw"></div>
                              <div class="foot_claw"></div>
                            </div>
                            <div class="track track_14">
                              <div class="foot left">
                                <div class="foot_claw"></div>
                                <div class="foot_claw"></div>
                                <div class="foot_claw"></div>
                              </div>
                              <div class="foot right">
                                <div class="foot_claw"></div>
                                <div class="foot_claw"></div>
                                <div class="foot_claw"></div>
                              </div>
                              <div class="track track_15">
                                <div class="foot left">
                                  <div class="foot_claw"></div>
                                  <div class="foot_claw"></div>
                                  <div class="foot_claw"></div>
                                </div>
                                <div class="foot right">
                                  <div class="foot_claw"></div>
                                  <div class="foot_claw"></div>
                                  <div class="foot_claw"></div>
                                </div>
                                <div class="track track_16">
                                  <div class="foot left">
                                    <div class="foot_claw"></div>
                                    <div class="foot_claw"></div>
                                    <div class="foot_claw"></div>
                                  </div>
                                  <div class="foot right">
                                    <div class="foot_claw"></div>
                                    <div class="foot_claw"></div>
                                    <div class="foot_claw"></div>
                                  </div>
                                  <div class="track track_17">
                                    <div class="foot left">
                                      <div class="foot_claw"></div>
                                      <div class="foot_claw"></div>
                                      <div class="foot_claw"></div>
                                    </div>
                                    <div class="foot right">
                                      <div class="foot_claw"></div>
                                      <div class="foot_claw"></div>
                                      <div class="foot_claw"></div>
                                    </div>
                                    <div class="track track_18">
                                      <div class="foot left">
                                        <div class="foot_claw"></div>
                                        <div class="foot_claw"></div>
                                        <div class="foot_claw"></div>
                                      </div>
                                      <div class="foot right">
                                        <div class="foot_claw"></div>
                                        <div class="foot_claw"></div>
                                        <div class="foot_claw"></div>
                                      </div>
                                      <div class="track track_19">
                                        <div class="foot left">
                                          <div class="foot_claw"></div>
                                          <div class="foot_claw"></div>
                                          <div class="foot_claw"></div>
                                        </div>
                                        <div class="foot right">
                                          <div class="foot_claw"></div>
                                          <div class="foot_claw"></div>
                                          <div class="foot_claw"></div>
                                        </div>
                                        <div class="track track_20">
                                          <div class="foot left">
                                            <div class="foot_claw"></div>
                                            <div class="foot_claw"></div>
                                            <div class="foot_claw"></div>
                                          </div>
                                          <div class="foot right">
                                            <div class="foot_claw"></div>
                                            <div class="foot_claw"></div>
                                            <div class="foot_claw"></div>
                                          </div>
                                          <div class="track track_21">
                                            <div class="foot left">
                                              <div class="foot_claw"></div>
                                              <div class="foot_claw"></div>
                                              <div class="foot_claw"></div>
                                            </div>
                                            <div class="foot right">
                                              <div class="foot_claw"></div>
                                              <div class="foot_claw"></div>
                                              <div class="foot_claw"></div>
                                            </div>
                                            <div class="track track_22">
                                              <div class="foot left">
                                                <div class="foot_claw"></div>
                                                <div class="foot_claw"></div>
                                                <div class="foot_claw"></div>
                                              </div>
                                              <div class="foot right">
                                                <div class="foot_claw"></div>
                                                <div class="foot_claw"></div>
                                                <div class="foot_claw"></div>
                                              </div>
                                              <div class="track track_23">
                                                <div class="foot left">
                                                  <div class="foot_claw"></div>
                                                  <div class="foot_claw"></div>
                                                  <div class="foot_claw"></div>
                                                </div>
                                                <div class="foot right">
                                                  <div class="foot_claw"></div>
                                                  <div class="foot_claw"></div>
                                                  <div class="foot_claw"></div>
                                                </div>
                                                <div class="track track_24">
                                                  <div class="foot left">
                                                    <div class="foot_claw"></div>
                                                    <div class="foot_claw"></div>
                                                    <div class="foot_claw"></div>
                                                  </div>
                                                  <div class="foot right">
                                                    <div class="foot_claw"></div>
                                                    <div class="foot_claw"></div>
                                                    <div class="foot_claw"></div>
                                                  </div>
                                                  <div class="track track_25">
                                                    <div class="foot left">
                                                      <div class="foot_claw"></div>
                                                      <div class="foot_claw"></div>
                                                      <div class="foot_claw"></div>
                                                    </div>
                                                    <div class="foot right">
                                                      <div class="foot_claw"></div>
                                                      <div class="foot_claw"></div>
                                                      <div class="foot_claw"></div>
                                                    </div>
                                                    <div class="track track_26">
                                                      <div class="foot left">
                                                        <div class="foot_claw"></div>
                                                        <div class="foot_claw"></div>
                                                        <div class="foot_claw"></div>
                                                      </div>
                                                      <div class="foot right">
                                                        <div class="foot_claw"></div>
                                                        <div class="foot_claw"></div>
                                                        <div class="foot_claw"></div>
                                                      </div>
                                                      <div class="track track_27">
                                                        <div class="foot left">
                                                          <div class="foot_claw"></div>
                                                          <div class="foot_claw"></div>
                                                          <div class="foot_claw"></div>
                                                        </div>
                                                        <div class="foot right">
                                                          <div class="foot_claw"></div>
                                                          <div class="foot_claw"></div>
                                                          <div class="foot_claw"></div>
                                                        </div>
                                                        <div class="track track_28">
                                                          <div class="foot left">
                                                            <div class="foot_claw"></div>
                                                            <div class="foot_claw"></div>
                                                            <div class="foot_claw"></div>
                                                          </div>
                                                          <div class="foot right">
                                                            <div class="foot_claw"></div>
                                                            <div class="foot_claw"></div>
                                                            <div class="foot_claw"></div>
                                                          </div>
                                                          <div class="track track_29">
                                                            <div class="foot left">
                                                              <div class="foot_claw"></div>
                                                              <div class="foot_claw"></div>
                                                              <div class="foot_claw"></div>
                                                            </div>
                                                            <div class="foot right">
                                                              <div class="foot_claw"></div>
                                                              <div class="foot_claw"></div>
                                                              <div class="foot_claw"></div>
                                                            </div>
                                                            <div class="track track_30">
                                                              <div class="foot left">
                                                                <div class="foot_claw"></div>
                                                                <div class="foot_claw"></div>
                                                                <div class="foot_claw"></div>
                                                              </div>
                                                              <div class="foot right">
                                                                <div class="foot_claw"></div>
                                                                <div class="foot_claw"></div>
                                                                <div class="foot_claw"></div>
                                                              </div>
                                                              <div class="track track_31">
                                                                <div class="foot left">
                                                                  <div class="foot_claw"></div>
                                                                  <div class="foot_claw"></div>
                                                                  <div class="foot_claw"></div>
                                                                </div>
                                                                <div class="foot right">
                                                                  <div class="foot_claw"></div>
                                                                  <div class="foot_claw"></div>
                                                                  <div class="foot_claw"></div>
                                                                </div>
                                                                <div class="track track_32">
                                                                  <div class="foot left">
                                                                    <div class="foot_claw"></div>
                                                                    <div class="foot_claw"></div>
                                                                    <div class="foot_claw"></div>
                                                                  </div>
                                                                  <div class="foot right">
                                                                    <div class="foot_claw"></div>
                                                                    <div class="foot_claw"></div>
                                                                    <div class="foot_claw"></div>
                                                                  </div>
                                                                  <div class="track track_33">
                                                                    <div class="foot left">
                                                                      <div class="foot_claw"></div>
                                                                      <div class="foot_claw"></div>
                                                                      <div class="foot_claw"></div>
                                                                    </div>
                                                                    <div class="foot right">
                                                                      <div class="foot_claw"></div>
                                                                      <div class="foot_claw"></div>
                                                                      <div class="foot_claw"></div>
                                                                    </div>
                                                                    <div class="track track_34">
                                                                      <div class="foot left">
                                                                        <div class="foot_claw"></div>
                                                                        <div class="foot_claw"></div>
                                                                        <div class="foot_claw"></div>
                                                                      </div>
                                                                      <div class="foot right">
                                                                        <div class="foot_claw"></div>
                                                                        <div class="foot_claw"></div>
                                                                        <div class="foot_claw"></div>
                                                                      </div>
                                                                      <div class="track track_35">
                                                                        <div class="foot left">
                                                                          <div class="foot_claw"></div>
                                                                          <div class="foot_claw"></div>
                                                                          <div class="foot_claw"></div>
                                                                        </div>
                                                                        <div class="foot right">
                                                                          <div class="foot_claw"></div>
                                                                          <div class="foot_claw"></div>
                                                                          <div class="foot_claw"></div>
                                                                        </div>
                                                                        <div class="track track_36">
                                                                          <div class="foot left">
                                                                            <div class="foot_claw"></div>
                                                                            <div class="foot_claw"></div>
                                                                            <div class="foot_claw"></div>
                                                                          </div>
                                                                          <div class="foot right">
                                                                            <div class="foot_claw"></div>
                                                                            <div class="foot_claw"></div>
                                                                            <div class="foot_claw"></div>
                                                                          </div>
                                                                          <div class="track track_37">
                                                                            <div class="foot left">
                                                                              <div class="foot_claw"></div>
                                                                              <div class="foot_claw"></div>
                                                                              <div class="foot_claw"></div>
                                                                            </div>
                                                                            <div class="foot right">
                                                                              <div class="foot_claw"></div>
                                                                              <div class="foot_claw"></div>
                                                                              <div class="foot_claw"></div>
                                                                            </div>
                                                                            <div class="track track_38">
                                                                              <div class="foot left">
                                                                                <div class="foot_claw"></div>
                                                                                <div class="foot_claw"></div>
                                                                                <div class="foot_claw"></div>
                                                                              </div>
                                                                              <div class="foot right">
                                                                                <div class="foot_claw"></div>
                                                                                <div class="foot_claw"></div>
                                                                                <div class="foot_claw"></div>
                                                                              </div>
                                                                              <div class="track track_39">
                                                                                <div class="foot left">
                                                                                  <div class="foot_claw"></div>
                                                                                  <div class="foot_claw"></div>
                                                                                  <div class="foot_claw"></div>
                                                                                </div>
                                                                                <div class="foot right">
                                                                                  <div class="foot_claw"></div>
                                                                                  <div class="foot_claw"></div>
                                                                                  <div class="foot_claw"></div>
                                                                                </div>
                                                                                <div class="track track_40">
                                                                                  <div class="foot left">
                                                                                    <div class="foot_claw"></div>
                                                                                    <div class="foot_claw"></div>
                                                                                    <div class="foot_claw"></div>
                                                                                  </div>
                                                                                  <div class="foot right">
                                                                                    <div class="foot_claw"></div>
                                                                                    <div class="foot_claw"></div>
                                                                                    <div class="foot_claw"></div>
                                                                                  </div>
                                                                                  <div class="track track_41">
                                                                                    <div class="foot left">
                                                                                      <div class="foot_claw"></div>
                                                                                      <div class="foot_claw"></div>
                                                                                      <div class="foot_claw"></div>
                                                                                    </div>
                                                                                    <div class="foot right">
                                                                                      <div class="foot_claw"></div>
                                                                                      <div class="foot_claw"></div>
                                                                                      <div class="foot_claw"></div>
                                                                                    </div>
                                                                                    <div class="track track_42">
                                                                                      <div class="foot left">
                                                                                        <div class="foot_claw"></div>
                                                                                        <div class="foot_claw"></div>
                                                                                        <div class="foot_claw"></div>
                                                                                      </div>
                                                                                      <div class="foot right">
                                                                                        <div class="foot_claw"></div>
                                                                                        <div class="foot_claw"></div>
                                                                                        <div class="foot_claw"></div>
                                                                                      </div>
                                                                                      <div class="track track_43">
                                                                                        <div class="foot left">
                                                                                          <div class="foot_claw"></div>
                                                                                          <div class="foot_claw"></div>
                                                                                          <div class="foot_claw"></div>
                                                                                        </div>
                                                                                        <div class="foot right">
                                                                                          <div class="foot_claw"></div>
                                                                                          <div class="foot_claw"></div>
                                                                                          <div class="foot_claw"></div>
                                                                                        </div>
                                                                                        <div class="track track_44">
                                                                                          <div class="foot left">
                                                                                            <div class="foot_claw"></div>
                                                                                            <div class="foot_claw"></div>
                                                                                            <div class="foot_claw"></div>
                                                                                          </div>
                                                                                          <div class="foot right">
                                                                                            <div class="foot_claw"></div>
                                                                                            <div class="foot_claw"></div>
                                                                                            <div class="foot_claw"></div>
                                                                                          </div>
                                                                                          <div class="track track_45">
                                                                                            <div class="foot left">
                                                                                              <div class="foot_claw"></div>
                                                                                              <div class="foot_claw"></div>
                                                                                              <div class="foot_claw"></div>
                                                                                            </div>
                                                                                            <div class="foot right">
                                                                                              <div class="foot_claw"></div>
                                                                                              <div class="foot_claw"></div>
                                                                                              <div class="foot_claw"></div>
                                                                                            </div>
                                                                                            <div class="track track_46">
                                                                                              <div class="foot left">
                                                                                                <div class="foot_claw"></div>
                                                                                                <div class="foot_claw"></div>
                                                                                                <div class="foot_claw"></div>
                                                                                              </div>
                                                                                              <div class="foot right">
                                                                                                <div class="foot_claw"></div>
                                                                                                <div class="foot_claw"></div>
                                                                                                <div class="foot_claw"></div>
                                                                                              </div>
                                                                                              <div class="track track_47">
                                                                                                <div class="foot left">
                                                                                                  <div class="foot_claw"></div>
                                                                                                  <div class="foot_claw"></div>
                                                                                                  <div class="foot_claw"></div>
                                                                                                </div>
                                                                                                <div class="foot right">
                                                                                                  <div class="foot_claw"></div>
                                                                                                  <div class="foot_claw"></div>
                                                                                                  <div class="foot_claw"></div>
                                                                                                </div>
                                                                                                <div class="track track_48">
                                                                                                  <div class="foot left">
                                                                                                    <div class="foot_claw"></div>
                                                                                                    <div class="foot_claw"></div>
                                                                                                    <div class="foot_claw"></div>
                                                                                                  </div>
                                                                                                  <div class="foot right">
                                                                                                    <div class="foot_claw"></div>
                                                                                                    <div class="foot_claw"></div>
                                                                                                    <div class="foot_claw"></div>
                                                                                                  </div>
                                                                                                  <div class="track track_49">
                                                                                                    <div class="foot left">
                                                                                                      <div class="foot_claw"></div>
                                                                                                      <div class="foot_claw"></div>
                                                                                                      <div class="foot_claw"></div>
                                                                                                    </div>
                                                                                                    <div class="foot right">
                                                                                                      <div class="foot_claw"></div>
                                                                                                      <div class="foot_claw"></div>
                                                                                                      <div class="foot_claw"></div>
                                                                                                    </div>
                                                                                                    <div class="track track_50">
                                                                                                      <div class="foot left">
                                                                                                        <div class="foot_claw"></div>
                                                                                                        <div class="foot_claw"></div>
                                                                                                        <div class="foot_claw"></div>
                                                                                                      </div>
                                                                                                      <div class="foot right">
                                                                                                        <div class="foot_claw"></div>
                                                                                                        <div class="foot_claw"></div>
                                                                                                        <div class="foot_claw"></div>
                                                                                                      </div>
                                                                                                    </div>
                                                                                                  </div>
                                                                                                </div>
                                                                                              </div>
                                                                                            </div>
                                                                                          </div>
                                                                                        </div>
                                                                                      </div>
                                                                                    </div>
                                                                                  </div>
                                                                                </div>
                                                                              </div>
                                                                            </div>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="epage.js"></script>
<script src="hocrux.js">
</script>

</body>
</html>
