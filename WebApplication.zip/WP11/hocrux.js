function viewDetails(str) {

    window.location.href = "riddlesdiary.php"+str;
  
  }
  
  /*
  
  it was a must to distort the soul to torn it apart, in order to create 
  the horcruxes .. at least you tried .. ?
  
  var CryptoJS = require(“crypto-js”);
  
  var decrypted = CryptoJS.AES.decrypt(encrypted, “champerOFsecrets”);
  
  console.log(decrypted.toString(CryptoJS.enc.Utf8));
  
  */

