<div id="footer">

<p style="color:white">Platform 9¾ &copy; Internal Server Error </p>

</div>