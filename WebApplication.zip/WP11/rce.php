<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error 401</title>
</head>
<body>
// Try to solve the riddle in order to get the flag ..
$the_horcrux = 'voldemort last hocrux is nagini.';
$patterns = array();
$patterns[0] = '/voldemort/';
$patterns[1] = '/last/';
$patterns[2] = '/hocrux/';
$patterns[3] = '/is/';
$replacements = array();
$replacements[3] = 'neville';
$replacements[2] = 'killed';
$replacements[1] = 'who';
$replacements[0] = '';
$x=preg_replace($patterns, $replacements, $the_horcrux);
$the_sowrd ='GryffindorSword';
$answer = preg_replace("/neville/", $the_sowrd, $x);
$flag = preg_replace('/\s+/', '', $answer);
</body>
</html>
