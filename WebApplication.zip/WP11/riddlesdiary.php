
<?php
$err2 = '';
$h2 = '';
$username="Phoenix";
// When the server gets a $_POST request
if(isset($_POST['post2'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag2'];
    $answer = $x; 
    // Check if $answer is true or false
    if($answer === $username)  {
        $h2='U2FsdGVkX19xBFa+j+znLTbWOGskhjPCNeO1sXLPmIpWJgj90gAGJZ2+il07y7GM';
    } else {
        $err2="WRONG!"; 
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riddle..</title>
</head>
<body>
>> hmmm, I see you .. Reopening the chamber of secrets
<br>
<br>
>> It wont be that easy .. It took me a quite long time 
<br>
<br>
<br>
<br>
I wAs patient. I wrote back. I was sympathetic, I was kinD. people siMply loved
me... no one's ever understood my [ciphers] like you do,... If I say it myself,I've always been able to charm the people I Needed."
The diary. My diary. [AES] been writing in it for months and months, telling me
all her Pitiful Worries and woes… So poured out her soul to me, and her soul happened to be exactly what I wanted… I grew stronger and stronger on a diet of her Deepest fears, her darkest secrets. 
- Tom riddle.
<br>
<br>
<br>
<br>
<br>
For the username: 
Those yellowed eyes results instant death, but not for the ones who rise from 
their own ashes. 
<br>
>> who is immune against those yellowed eyes ?
<br>
>> 
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag2" placeholder="Your answer">
    <input type="submit"  name="post2" value="Submit answer">
    <p style="color:brown;"><?php echo $err2;?></p>
    <p><?php echo $h2;?></p>
</form>
</body>
</html>

