<?php
/*
Website: https://codepen.io/vikramcodes/pen/QWNbVmZ
*/
?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="slideShow.css">
    <link rel="stylesheet" href="Button.css">
    <link rel="stylesheet" href="../nav-css/nav.css">
    <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <div id='stars'></div>
    <div id='stars2'></div>
    <div id='stars3'></div>
</head>
<body>
<nav>
    <!-- image -->
    <div class="logo heading">
      <img src="../logo.png" width="50px" height="auto">
    </div>
    <header>
      <div class="container1" >
          <div id="branding">
              <div id="logo" >
      </div>
          <ul>
          <li><a class="active" href="../WelcomePage/welcomepage.php"> HOME </a></li>
          <li><a  href="../slide-page/slideShow.php">ABOUT US</a></li>
          <li><a  href="../Feedback-page/feedbacks.php">FEEDBACK</a></li>
          </ul>
          </nav>
      </div>
    </div>
    
        </header>
  </nav>
  <div class="absolute-wrapper">
    <div class="colored-backgrounds">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <main>
    <div class="content">
      <div class="heading">
        <h1 style="color: #dce6ec;">Your Virtual Diagon<br>Alley</h1>
        <p style="color: #dce6ec;">
          Are you a brave Gryffindor? A cunning Slytherin? <br> A loyal Hufflepuff?
          Or a wise Ravenclaw? Whichever <br>house you belong to, we’ll show you how
          to decorate<br> your own chamber of secret with the magical things<br> you will
          find in our shop ! 
          <br>
        </p>
        <form action="../Registerations/user/signup-page.php">
          <button type="submit">Start Your Journey</button>
        </form>
        <br>
      </div>
    </div>
    </br></br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>

    <?php include('../../../light-footer.php');?> 
    <div class="wrapper">
      <div class="images">
        <div class="image"></div>
        <div class="image"></div>
        <div class="image"></div>
        <div class="image"></div>
        <div class="image"></div>
      </div>
    </div>
    <div class="navigation">
      <div style="color: #dce6ec;" class="right">
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-right" width="26" height="26" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
          <path stroke="none" d="M0 0h24v24H0z" />
          <polyline points="9 6 15 12 9 18" />
        </svg>
      </div>
      <div style="color: #dce6ec;" class="left">
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-left" width="26" height="26" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
          <path stroke="none" d="M0 0h24v24H0z" />
          <polyline points="15 6 9 12 15 18" />
        </svg>
      </div>
    </div>
  </main>
      <script src="slideShow.js"></script>
      <script src="../payment-page/payment.js"></script>

</body>
<!-- before you look for the flag let me tell you a short story-->
<!-- Voldemort gathered his Death Eaters and army to launch a 
final assault on Hogwarts .. the key is the year of the battle (1998)-->
<!-- 
//to ensure that no underage student yields to temptation, I will be drawing an Age Line around 
// the Goblet of Fire once it has been placed in the entrance hall. Nobody under the age of ...?
// enter the age to get the flag.
// call a function named flag{} 
// keep using conlose.log till you find your way out. 
// if there was any form of cheating..
 players will be expelled from the game xOR worse then they will lose 64 points from thier houses-->
</html>
