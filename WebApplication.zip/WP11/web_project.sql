-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 24, 2022 at 01:50 PM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(9, 'alghala', '7ef393466381efd53b56840a1071519d'),
(10, 'lama', 'b9be9dc7e9d8cee582662b3d9b415d2e'),
(11, 'Phoenix', '56c43d6fb69b9f4d9d29a924ec9335c6');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `username`, `email`, `feedback`) VALUES
(5, 'luna', 'luna@gmail.com', 'nice try'),
(6, 'luna', 'luna@gmail.com', 'nice glasses'),
(12, 'neville', 'longbottom@gmail.com', 'nice'),
(13, 'shahad', 'shahad@gmail.com', 'كشوووخي'),
(14, 'aaa', 'a@gmail.com', 'صداع'),
(15, 'ron', 'ron@gmail.com', 'nice web Application!!!');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `price` double(9,2) NOT NULL,
  `image` varchar(250) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `code`, `description`, `price`, `image`, `quantity`) VALUES
(1, 'HERMIONES TIME TURNER PIN', 'time01', 'A replica of Hermione\'s Time-Turner, on a pin badge. It has glittering rhinestones to represent an hourglass.', 707.00, 'product-images/time.jpg', 9),
(2, 'THE TRIWIZARD LIGHT CUP', 'light01', 'Inspired by the golden cup, When switched on stem lights up bright blue to emulate the way the cup glows as seen.', 400.00, 'product-images/cup.jpg', 10),
(3, 'GOLDEN SNITCH KEYRING', 'snitch01', 'This keyring features a 3D replica of the iconic Golden Snitch, its a metallic gold color with silver wing detailing.', 100.00, 'product-images/snitch.jpg', 10),
(4, 'THE HORCRUX RING SOUVENIR', 'ring01', 'This Ring is plated in 24 gold and comes in a customized collector\'s display box. It is available in size 10 only.', 51.00, 'product-images/ring.jpg', 10),
(5, 'HARRY POTTER CHARM BRACELET SET', 'brace01', 'this bracelet has three charms including the Platform 9¾ logo, a Golden Snitch and Deathly Hallows emblem, each displayed on a silver plated charm bail', 150.00, 'product-images/bre.jpg', 10),
(6, 'SET OF GRINGOTTS BANK COINS', 'coins01', 'This is a replicate of the money used in the Harry Potter film series. Each double-sided coin is hand struck in 24k gold, silver or bronze.', 300.00, 'product-images/coin.jpg', 10),
(7, 'LUNAS SPECTRESPECS PIN BADGE', 'pin01', 'Luna Lovegood was first seen wearing a pair of Spectrespecs Luna Lovegood on the train ride to Hogwarts in 1996. ', 300.00, 'product-images/luna.jpg', 10),
(8, 'TOM RIDDLE REPLICA DIARY', 'diary01', 'This is a replica of Riddle\'s Diary but be careful that he doesn\'t write back! its leather journal measures 20cm x 13cm with 142 blank pages.', 70.00, 'product-images/tom.jpg', 10),
(9, 'HOGWARTS EXPRESS SOUVENIR TICKET', 'ticket01', 'This ticket is embellished with gold foil, and is based on the original artwork by MinaLima, the graphic duo.', 100.00, 'product-images/ticket.jpg', 10),
(10, 'THE MARAUDERS MAP', 'map01', 'This Map replica. It shows every classroom and hallway, including all the hidden secret passages and the location of every person in the Hogwarts grounds.', 8320.00, 'product-images/map.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'harry', '5f4dcc3b5aa765d61d8327deb882cf99', 'harry@gmail.com'),
(2, 'draco', '0ab30270b18d3d6af7202bf744adb7ff', 'draco@gmail.com'),
(5, 'snape', 'c5c85ff214e6363fb656c18d2171db22', 'snape@gmail.com'),
(7, 'ron', '1bded3db8ce18ae0fd61ae5b2b6ce19e', 'ron@gmail.com'),
(12, 'luna', '69d7c59979ec8da4be152fd020d05645', 'luna@gmail.com'),
(13, 'neville', 'ac0203e52da9f7d4d70fd02b661c41d1', 'longbottom@gmail.com'),
(15, 'newt', 'f188286b962dab6cfc1639ae5e7cea75', 'newt@gmail.com'),
(18, 'lama', '25873e159d36d8c7218c74bbfd3d7e02', 'lama@gmail.com'),
(51, 'bobo', '81dc9bdb52d04dc20036dbd8313ed055', 'bobo@gmail.com'),
(61, 'eeee', '86871b9b1ab33b0834d455c540d82e89', 'ronee33@gm9ail.com'),
(62, 'rrrr', '50f84daf3a6dfd6a9f20c9f8ef428942', 'ronee33@gm5ail.com'),
(63, 'ronn', '45798f269709550d6f6e1d2cf4b7d485', 'ron1@gmail.com'),
(69, 'ronee', '1bded3db8ce18ae0fd61ae5b2b6ce19e', 'ronn3@gmail.com'),
(70, 'lunna', '333f8b44a629c8943a24b91a4a14ecf9', 'luna1@gmail.com'),
(71, 'fred', '95af5f06522282e0532b6e0378dcef5f', 'fred@gmail.com'),
(72, 'charlie', '9d8ee494d811627d252bac7038356ff4', 'Charlie1234@google.com'),
(76, 'hermione', '429b873fd33cec1e47b0dc9a69b416d3', 'granger@gmail.com'),
(77, 'maryam', '06f88ed9e5dcf747fa6d1a8bdbc6fdc6', 'maryam@gmail.com'),
(78, 'shahad', '426e7ef4934e492b830aa91e3697ea2d', 'shahad@gmail.com'),
(79, 'alghalaa', '2dddbe8f63f2aec6132bb9811f93635a', 'admin@gmail.com'),
(81, 'alghala', '4f42142df925126c6bdfd337b6716cba', 'alghala@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
