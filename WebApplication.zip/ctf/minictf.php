<?php
// errors
$err1 = '';
$err2 = '';
$err3 = '';
$err4 = '';
$err5 = '';
$err6 = '';
$err7 = '';
// hints
$h1 = '';
$h2 = '';
$h3 = '';
$h4 = '';
$h5 = '';
$h6 = '';
$h7 = '';
// Flags
$f1 = 'flag{”L00k1nG_4_AL0ck3t”}';
$f2 = 'flag{”SaLAZaR_slYth3rin_l0cket”}';
$f3 = 'flag{”h3lga_huff13PUFF_CUp”}';
$f4 = 'flag{”GryffindorSwordkilledwhonagini”}';
$f5 = 'flag{”Wit-beyond-measure-is-mans-greatest-treasure”}';
$f6 = 'Basilisk{has_4_d34d1y_gaze}';
$f7 = 'flag{you_found_the_last_hocrux!}';

if(isset($_POST['post1'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag1'];

    $answer = $x; 

    // Check if $answer is true or false
    if($answer === $f1) {
        $h1='Congrats! you little muggle now look for the locket.';
    } else {
        $err1="WRONG flag!, If  Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

// Flag 2
// When the server gets a $_POST request
if(isset($_POST['post2'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag2'];
    $answer = $x; 
    // Check if $answer is true or false
    if($answer === $f2) {
        $h2='Helga had a cup ! But we have another slide that contains the cup look for the other cup you might find the truth?';
    } else {
        $err2="WRONG flag!, If Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

// Flag 3
// When the server gets a $_POST request
if(isset($_POST['post3'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag3'];
    $answer = $x; 


    // Check if $answer is true or false
    if($answer === $f3) {
        $h3='will will .. You may be a muggle, but you have a skilled cyber brain... thats my secret ..(Feedback)...';
    } else {
        $err3="WRONG flag!, If Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

// Flag 4
// When the server gets a $_POST request
if(isset($_POST['post4'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag4'];
    $answer = $x; 
   

    // Check if $answer is true or false
    if($answer === $f4) {
        $h4='Just because you have the emotional range of a teaspoon doesn’t mean we all have..but ill make sure that the next 2 challenges won’t be that easy.. LFI - flag5.txt';
    } else {
        $err4="WRONG flag!, If Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

// Flag 5
// When the server gets a $_POST request
if(isset($_POST['post5'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag5'];
    $answer = $x; 

    // Check if $answer is true or false
    if($answer === $f5) {
        $h5='Congrats! you little muggle now look for unauthorised access page...check the endings';
    } else {
        $err5="WRONG flag!, If Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

// Flag 6
// When the server gets a $_POST request
if(isset($_POST['post6'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag6'];
    $answer = $x; 

    // Check if $answer is true or false
    if($answer === $f6) {
        $h6='username and password for what?';
    } else {
        $err6="WRONG flag!, If Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

// Flag 7
// When the server gets a $_POST request
if(isset($_POST['post7'])) {

    // Set the variable X to whatever the user put in
    $x = $_POST['flag7'];
    $answer = $x; 

    // Check if $answer is true or false
    if($answer === $f7) {
        $h7='Done..all was well';
    } else {
        $err7="WRONG flag!, If Voldemort were still around, I’d tell him you were the Chosen One !"; 
    }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="minictf.css">
    <title>TriCTF Tournament</title>
</head>
<body>
    <div class="start">
    <p>The TriCTF Tournament consists of a series of challanges designed to</p>
    <P>test the champions in many different ways: their magical powers,</P>
    <p>their daring, and their ability to cope with various cyber challanges </p>
    <h4> Enter your answer in order to find the hidden flag: </h4>
    </div>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag1" placeholder="Your answer">
    <input type="submit" name="post1" value="Submit answer">
    <p style="color:brown;"><?php echo $err1;?></p>
    <p><?php echo $h1;?></p>
</form>
<br>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag2" placeholder="Your answer">
    <input type="submit"  name="post2" value="Submit answer">
    <p style="color:brown;"><?php echo $err2;?></p>
    <p><?php echo $h2;?></p>
</form>
<br>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag3" placeholder="Your answer">
    <input type="submit"  name="post3" value="Submit answer">
    <p style="color:brown;"><?php echo $err3;?></p>
    <p><?php echo $h3;?></p>
</form>
<br>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag4" placeholder="Your answer">
    <input type="submit"  name="post4" value="Submit answer">
    <p style="color:brown;"><?php echo $err4;?></p>
    <p><?php echo $h4;?></p>
</form>
<br>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag5" placeholder="Your answer">
    <input type="submit"   name="post5" value="Submit answer">
    <p style="color:brown;"><?php echo $err5;?></p>
    <p><?php echo $h5;?></p>
</form>
<br>
<form method="post">
    <label> Flag: </label> format is not a flag{...}
    <input type="text" name="flag6" placeholder="Your answer">
    <input type="submit"  name="post6" value="Submit answer">
    <p style="color:brown;"><?php echo $err6;?></p>
    <p><?php echo $h6;?></p>
</form>
<br>
<form method="post">
    <label> Flag: </label>
    <input type="text" name="flag7" placeholder="Your answer">
    <input type="submit"  name="post7" value="Submit answer">
    <p style="color:brown;"><?php echo $err7;?></p>
    <p><?php echo $h7;?></p>
</form> 
<br>
<br>
</body>
</html>


